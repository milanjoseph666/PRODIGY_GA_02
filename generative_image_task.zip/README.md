# Generative AI Task: Image Generation with Pre-trained Models

This project demonstrates how to use pre-trained generative models such as Stable Diffusion to generate images from text prompts.

## References
1. https://www.tensorflow.org/tutorials/generative/generate_images_with_stable_diffusion
2. https://colab.research.google.com/github/robgon-art/e-dall-e/blob/main/DALL_E_Mini_Image_Generator.ipynb
3. https://towardsdatascience.com/e-dall-e-creating-digital-art-with-varying-aspect-ratios-5de260f4713d/
4. https://github.com/faizonly5953/Diffusion-Colab

## Instructions
1. Make sure you have Python 3.8+ and necessary libraries installed.
2. Run `pip install diffusers transformers torch` to install dependencies.
3. Execute `generate_images.py` to generate an image from the text prompt.
