# generate_images.py
# This script demonstrates using pretrained models like Stable Diffusion
# to generate images from text prompts.

from diffusers import StableDiffusionPipeline
import torch

def generate_image(prompt: str, output_path: str):
    pipe = StableDiffusionPipeline.from_pretrained("CompVis/stable-diffusion-v1-4")
    pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    image = pipe(prompt).images[0]
    image.save(output_path)

if __name__ == "__main__":
    prompt = "a futuristic city skyline at sunset"
    output_path = "output_image.png"
    generate_image(prompt, output_path)
    print(f"Image generated and saved to {output_path}")
